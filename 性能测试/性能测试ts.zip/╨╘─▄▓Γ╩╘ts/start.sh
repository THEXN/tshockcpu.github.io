#!/bin/bash
while true; do
./TShock.Server -ip 0.0.0.0 -port 7777 -world ./性能测试大世界.wld -lang 7
sleep 5
done